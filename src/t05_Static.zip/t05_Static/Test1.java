package t05_Static;

public class Test1 {
	static int su = 100;
	
	static void add(int su1, int su2) {
		int res = su1 + su2;
		System.out.println(su1 + " + " + su2 + " = " + res);
	}
}
