package t05_Static;

public class Test3Run {
	public static void main(String[] args) {
//		Test3 t3=new Test3();
//		System.out.println("nation : " +t3.nation);
//		System.out.println("jumin : " +t3.jumin);
		
   	System.out.println("nation : " +Test3.NATION);
  	System.out.println("jumin : " +Test3.JUMIN);
		
	}
}
