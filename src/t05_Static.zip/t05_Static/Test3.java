package t05_Static;

public class Test3 {
//	static final String nation="Korea"; static final은 값을 못 바꾼다.
//	static final String jumin="123-456"; //선언한 값이 있어야 static final쓸수 있다.
	static final String NATION="Korea";
	static final String JUMIN="123-456"; //선언한 값이 있어야 static final쓸수 있다.
	
	public Test3() {}
}
