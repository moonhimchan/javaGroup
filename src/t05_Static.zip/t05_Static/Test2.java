package t05_Static;

public class Test2 {
	final String nation="Korea";
	final String jumin;
	
	//public Test2() {} //The blank final field jumin may not have been initialized
	
	Test2(String jumin) {
		this.jumin=jumin;
	}	
}
