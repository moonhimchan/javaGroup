package t05_Static;

public class Test4 {
	int su=500;
	
	void mod1() {
		System.out.println("su :" +su);
	}
}
