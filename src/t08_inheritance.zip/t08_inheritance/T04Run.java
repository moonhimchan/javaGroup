package t08_inheritance;

public class T04Run {
	public static void main(String[] args) {
		new T04_C(10);
		System.out.println("T04Run클래스");
	}
}
