package t08_inheritance;

public class T03_P {
	public T03_P() {
		System.out.println("T03_p클래스");
	}
}
