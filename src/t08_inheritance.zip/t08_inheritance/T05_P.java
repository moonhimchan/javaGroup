package t08_inheritance;

public class T05_P {
	double pi= 3.14;
	
	void areaCircle (int r) {
		double area = r*r*pi;
		System.out.println("원넓이 : " +area);
	}
}
