package t08_inheritance;

public class T05Run {
		public static void main(String[] args) {
			T05_C t5=new T05_C();
			
			t5.areaCircle(10);
		}
}
