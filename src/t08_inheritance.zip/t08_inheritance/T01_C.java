package t08_inheritance;

public class T01_C extends T01_P {
	void mod2() {
		System.out.println("이곳은 T01_C 클래스의 mod2메소드입니다.");
	}
}
