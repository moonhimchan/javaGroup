package t08_inheritance;

public class T03_C extends T03_P{
	public T03_C() {
		super(); //super()항상 첫번째줄에 만들어야된다.
		System.out.println("T03_C클래스");
	}
}
