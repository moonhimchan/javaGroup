package t08_inheritance;

// 할아버지
public class T01_J {
	int add(int su1, int su2) {
		return su1 + su2;
	}
}
