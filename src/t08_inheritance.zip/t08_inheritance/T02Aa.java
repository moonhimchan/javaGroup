package t08_inheritance;

public class T02Aa {

	// 사각형의 면적(w * h)
	int areaRec(int w, int h) {
		return w * h;
	}
	
	// 사각형 둘레(w*2 + h*2)
	int lenRec(int w, int h) {
		return (w*2) + (h*2);
	}
	
}
