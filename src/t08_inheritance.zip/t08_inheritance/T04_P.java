package t08_inheritance;

public class T04_P {
	private int su;
	
	public T04_P(int su) {
		this.su=su;
		System.out.println("T04_p클래스의 su : " +this.su);
	}
}
