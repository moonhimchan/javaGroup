package t08_inheritance;

public class T05_C extends T05_P {

	@Override
	void areaCircle(int r) {
		
	}
	
}
/*부모재산을 재정의해서 사용하는게 오버라이드이다.
  오버라이드는 메소드 밖에 없다.  */
//부모가 아닌 자식것을 실행시킴 오버라이드는 메소드의 선언부가 똑같아야 한다.