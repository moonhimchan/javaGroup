package t08_inheritance;

public class T04_C extends T04_P{
	public T04_C(int su) {
		super(su); //super()항상 첫번째줄에 만들어야된다. 
		System.out.println("T04_C클래스");
	}
}
