package t08_inheritance;

public class T03Run {
	public static void main(String[] args) {
		new T03_C();
		System.out.println("T03Run클래스");
	}
}
