package t04_method;

public class Test2 {
  void mod1() {
  	System.out.println("안녕1");
  }
  
  void mod1(String name) {
  	System.out.println(name + "안녕1");
  }
  
  void mod1(String name, int age) {
  	System.out.println(name + "안녕1, 나이는 " + age);
  }
  
  void mod1(int age, String name) {
  	System.out.println(name + "안녕1, 나이는 " + age);
  }
  
//  void mod1(String irum, int nai) {
//  	System.out.println(irum + "안녕1, 나이는 " + nai);
//  }
  
//  String mod1(int age, String name) {
//  return (name + "안녕1, 나이는 " + age);
//}
}
