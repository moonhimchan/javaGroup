package t04_method;

public class Test3Run {
	public static void main(String[] args) {
	  Test3 t31=new Test3();
	  
	  t31.su=10;
	  t31.mod2();
	  
	  t31.mod1(20);
	  t31.mod2();
	}
}
