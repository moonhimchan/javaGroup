package t04_method;

public class Test2Run {
	public static void main(String[] args) {
		Test2 t21=new Test2();
		
		t21.mod1();
		t21.mod1("홍길동");
		t21.mod1("홍길동",22);
		t21.mod1(33,"홍길동");
	}
}
