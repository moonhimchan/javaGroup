package t04_method;

public class Test4 {
	int gas;
	
  void run() {
  	while(gas>0) {		  	
  	System.out.println(gas);
  	gas--;
  	}
  	System.out.println("자동차가 멈춥니다.");
  }
}
